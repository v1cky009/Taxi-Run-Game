import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Score {

    private Map<String, Integer> scoresMap = new HashMap<>();

    // Method to update scores
    public void updateScores(String playerName, int score) {
        int currentScore = scoresMap.getOrDefault(playerName, 0);
        if (score > currentScore) {
            scoresMap.put(playerName, score);
            saveScores();
        }
    }

    // Method to read scores from file
    public void readScores() {
        try {
            FileInputStream fstream = new FileInputStream("Scores.dat");
            ObjectInputStream inputFile = new ObjectInputStream(fstream);
            scoresMap = (HashMap<String, Integer>) inputFile.readObject();
            inputFile.close();
        } catch (IOException | ClassNotFoundException e) {
            // If there's no file or error, create an empty map
            scoresMap = new HashMap<>();
        }
    }

    // Method to save scores to file
    public void saveScores() {
        try {
            FileOutputStream fstream = new FileOutputStream("Scores.dat");
            ObjectOutputStream outputFile = new ObjectOutputStream(fstream);
            outputFile.writeObject(scoresMap);
            outputFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to get the high score for a player
    public int getHighScore(String playerName) {
        return scoresMap.getOrDefault(playerName, 0);
    }

    // Method to get all scores
    public Map<String, Integer> getAllScores() {
        return scoresMap;
    }
}
