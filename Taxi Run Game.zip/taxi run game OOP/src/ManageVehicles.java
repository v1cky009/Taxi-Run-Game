import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

enum CarDirection {
    LEFT, RIGHT
}

enum CarColor {
    BLUE, GREEN, GREY, ORANGE, PURPLE, RED, WHITE, YELLOW
}

enum TrainColor {
    BLUE, GREEN, GREY, ORANGE, PURPLE, RED, WHITE, YELLOW
}

class Vehicle {
    private String imagePath;
    private int xLoc;
    private int yLoc;
    private int xDir;
    private int yDir;

    public Vehicle(String imagePath, int xLoc, int yLoc, int xDir, int yDir) {
        this.imagePath = imagePath;
        this.xLoc = xLoc;
        this.yLoc = yLoc;
        this.xDir = xDir;
        this.yDir = yDir;
    }

    public String getImagePath() {
        return imagePath;
    }

    public int getXLoc() {
        return xLoc;
    }

    public void setXLoc(int xLoc) {
        this.xLoc = xLoc;
    }

    public int getYLoc() {
        return yLoc;
    }

    public void setYLoc(int yLoc) {
        this.yLoc = yLoc;
    }

    public int getXDir() {
        return xDir;
    }

    public void setXDir(int xDir) {
        this.xDir = xDir;
    }

    public int getYDir() {
        return yDir;
    }

    public void setYDir(int yDir) {
        this.yDir = yDir;
    }
}

class Car extends Vehicle {
    public Car(String imagePath, int xLoc, int yLoc, int xDir, int yDir) {
        super(imagePath, xLoc, yLoc, xDir, yDir);
    }
}

class Train extends Vehicle {
    public Train(String imagePath, int xLoc, int yLoc, int xDir, int yDir) {
        super(imagePath, xLoc, yLoc, xDir, yDir);
    }
}

class ManageVehicles {
    private Random rand = new Random();
    private Queue<Vehicle> carQueue = new LinkedList<>();
    private Queue<Vehicle> trainQueue = new LinkedList<>();

    public Queue<Vehicle> getCarQueue() {
        return carQueue;
    }

    public Queue<Vehicle> getTrainQueue() {
        return trainQueue;
    }

    public void updateVehicles(int stripYLoc) {
        carQueue.add(setCar(stripYLoc));
        trainQueue.add(setTrain(stripYLoc));
    }

    Vehicle setCar(int stripYLoc) {
        CarDirection direction = (rand.nextInt(2) == 1) ? CarDirection.RIGHT : CarDirection.LEFT;
        CarColor carColor = CarColor.values()[rand.nextInt(CarColor.values().length)];
        String imagePath = (direction == CarDirection.LEFT) ?
                String.format("/Car_Left/Car_Left_%s.png", carColor.name()) :
                String.format("/Car_Right/Car_Right_%s.png", carColor.name());

        Car car = new Car(imagePath, (direction == CarDirection.LEFT) ? 900 : -200, stripYLoc,
                (direction == CarDirection.LEFT) ? -(rand.nextInt(10) + 10) : (rand.nextInt(10) + 10), 2);

        return car;
    }

    Vehicle setTrain(int stripYLoc) {
        TrainColor trainColor = TrainColor.values()[rand.nextInt(TrainColor.values().length)];
        String imagePath = String.format("/Trains/Train_%s.png", trainColor.name());

        Train train = new Train(imagePath, (rand.nextInt(2) == 1) ? 900 : -1500, stripYLoc,
                (rand.nextInt(2) == 1) ? -(rand.nextInt(10) + 30) : (rand.nextInt(10) + 30), 2);

        return train;
    }
}
